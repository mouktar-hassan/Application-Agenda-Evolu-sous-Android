package Entity;

public class Agenda {

	private final int id_agenda=1;
	
	public Agenda() {}

	public int getId_agenda() {
		return id_agenda;
	}
	
	
}
