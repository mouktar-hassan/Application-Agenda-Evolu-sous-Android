package Entity;

public class Meteo extends Evenement{
	
	//constructeur vide
	public Meteo() {
		super();
	}
	
	//methode pour prendre en compte le changement Meteo
	public void updateMeteo(String msg) {
		msg="GPS modifiee";
	}

}
