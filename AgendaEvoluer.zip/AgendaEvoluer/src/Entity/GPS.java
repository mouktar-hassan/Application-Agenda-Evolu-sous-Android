package Entity;

public class GPS extends Evenement{
	
	
	public GPS() {
		super();
	}
	
	public void updateGPS(String msg) {
		msg="GPS modifee";
	}

}
