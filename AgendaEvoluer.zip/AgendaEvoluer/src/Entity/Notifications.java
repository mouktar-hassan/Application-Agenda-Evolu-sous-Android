package Entity;
import java.util.Timer;

public class Notifications implements Observateur {
	
	private int idAgenda;
	private String titre;
	private String description;
	private String date_debut_event;
	private int Evenement_id;
	
	//constructeur vide
	public Notifications() {}
	//contructeur parametree
	public Notifications(int idAgenda, String titre, String description, String date_debut_event, int Evenement_id) {
		this.idAgenda=idAgenda;
		this.titre=titre;
		this.description=description;
		this.date_debut_event=date_debut_event;
		this.Evenement_id=Evenement_id;
	}
	
	//getters et setters des differents elements
	
	public int getIdAgenda() {
		return idAgenda;
	}
	public void setIdAgenda(int idAgenda) {
		this.idAgenda = idAgenda;
	}
	public String getTitre() {
		return titre;
	}
	public void setTitre(String titre) {
		this.titre = titre;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getdate_debut_event() {
		return date_debut_event;
	}
	public void setdate_debut_event(String date_debut_event) {
		this.date_debut_event = date_debut_event;
	}
	public int getEvenement_id() {
		return Evenement_id;
	}
	public void setEvenement_id(int evenement_id) {
		Evenement_id = evenement_id;
	}
	
	
	@Override
	public void actualiser(Observateur o) {
		// TODO Auto-generated method stub
		if(o instanceof Evenement) {
			Evenement ev=(Evenement)o;
			
		}
		
	}
	
	

}
