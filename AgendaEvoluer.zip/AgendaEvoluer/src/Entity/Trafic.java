package Entity;

public class Trafic extends Evenement {

	
	
	//constructeur vide 
	public Trafic() {
		super();
	}
	
	
	
	
	
	
	
}
