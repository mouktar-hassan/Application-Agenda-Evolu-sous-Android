package Entity;

public interface Observateur {

	//methode pour mettre a jour l'etat de l'observateur
	public void actualiser(Observateur o);
}
