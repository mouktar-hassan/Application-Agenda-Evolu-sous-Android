package Entity;
import java.util.ArrayList;


public class Evenement implements Observable {
	private int idEve;
	private String titre;	
	private String date_debut;
	private String date_fin;	
	private String lieu;
	private String type;
	private String description;
	private int Utilisateur_id;
	private String alerte;
	//liste d'observateurs 
	ArrayList<Observateur> listeObservateurs;
	//constructeur vide 
    public Evenement() {}
    
    //constructeur parametree
    public Evenement(int idEve, String titre, String date_debut, String date_fin, 
    		String lieu, String type, String description,String alerte) {
    	this.idEve=idEve;
    	this.titre=titre;    
    	this.date_debut=date_debut;
    	this.date_fin=date_fin;    	
    	this.lieu=lieu;
    	this.type=type;
    	this.description=description;
    	this.alerte=alerte;
    	//instance de la liste observateur
    	listeObservateurs=new ArrayList<Observateur>();
    }
    
    
	//getters et setters des differents elements
    
    public int getIdEve() {
		return idEve;
	}

	public void setIdEve(int idEve) {
		this.idEve = idEve;
	}

	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}


	public String getDate_debut() {
		return date_debut;
	}

	public void setDate_debut(String date_debut) {
		this.date_debut = date_debut;
	}

	public String getDate_fin() {
		return date_fin;
	}

	public void setDate_fin(String date_fin) {
		this.date_fin = date_fin;
	}
	
	public String getLieu() {
		return lieu;
	}

	public void setLieu(String lieu) {
		this.lieu = lieu;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getUtilisateur_id() {
		return Utilisateur_id;
	}

	public void setUtilisateur_id(int utilisateur_id) {
		Utilisateur_id = utilisateur_id;
	}
    
	public String getAlerte() {
		return alerte;
	}

	public void setAlerte(String alerte) {
		this.alerte = alerte;
	}

	@Override
	public void ajouterObservateur(Observateur o) {
		// TODO Auto-generated method stub
		listeObservateurs.add(o);
	}		

	public ArrayList<Observateur> getListeObservateurs() {
		return listeObservateurs;
	}

	public void setListeObservateurs(ArrayList<Observateur> listeObservateurs) {
		this.listeObservateurs = listeObservateurs;
	}

	@Override
	public void supprimerObservateur(Observateur o) {
		// TODO Auto-generated method stub
		listeObservateurs.remove(o);
		
	}
	@Override
	public void notifierObservateurs() {
		// TODO Auto-generated method stub
		for(int i=0; i< listeObservateurs.size(); i++) {
			Observateur o=listeObservateurs.get(i);
			o.actualiser(o);
			
		}
		
	}
	
	

}
