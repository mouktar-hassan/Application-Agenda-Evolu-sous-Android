package Dao;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.example.agendaevoluer.*;

import Entity.Evenement;
import Entity.Notifications;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class NotificationDao {
	
	
    public static final String TABLE_NAME="Notification";
	public static final String KEY_ID_AGENDA="id_agenda";
	public static final String KEY_TITRE_NOTIFICATION="titre";
	public static final String KEY_DESCRIPTION_NOTIFICATION="description";
	public static final String KEY_DATE_DEBUT_EVENT="date_debut";
	public static final String KEY_EVENEMENT_ID="Evenement_id";	
	private SQLiteDatabase bdd;
	private DatabaseHelper maBaseSqLite;
	
	
	public NotificationDao(Context context)
	{
		maBaseSqLite=DatabaseHelper.getInstance(context);
	}
	
	public static final String CREATE_TABLE_NOTIFICATION=" ";
	public void open()
	{
		bdd=maBaseSqLite.getWritableDatabase();
	}
	
	public void close()
	{
		bdd.close();
	}
	
	public long AjouterNotification(Notifications notifications)
	{
		ContentValues values=new ContentValues();
		values.put(KEY_TITRE_NOTIFICATION,notifications.getTitre());
		values.put(KEY_DESCRIPTION_NOTIFICATION,notifications.getDescription());
		values.put(KEY_DATE_DEBUT_EVENT,notifications.getdate_debut_event());
		values.put(KEY_EVENEMENT_ID,notifications.getEvenement_id());			
		
		return bdd.insert(TABLE_NAME, null, values);
	}
	
	public int ModifierNotification(Notifications notifications)
	{
		ContentValues values=new ContentValues();
		values.put(KEY_TITRE_NOTIFICATION,notifications.getTitre());
		values.put(KEY_DESCRIPTION_NOTIFICATION,notifications.getDescription());
		values.put(KEY_DATE_DEBUT_EVENT,notifications.getIdAgenda());
		values.put(KEY_EVENEMENT_ID,notifications.getEvenement_id());	
		String where=KEY_ID_AGENDA+" = ?";
		String[] whereArgs={notifications.getIdAgenda()+""};
		return bdd.update(TABLE_NAME, values, where, whereArgs);
	}
	
	public int SupprimerNotification(Notifications notifications)
	{
		String where = KEY_ID_AGENDA+ " = ?";
		String[] whereArgs = {notifications.getIdAgenda()+ ""};
		return bdd.delete(TABLE_NAME,where, whereArgs);
	}
	
	public Notifications getListNotification(int id)
	{
		Notifications notifications=new Notifications();
		
		Cursor c=bdd.rawQuery("SELECT * FROM "+TABLE_NAME+" WHERE "+KEY_ID_AGENDA+"="+id, null);
		if(c.moveToFirst())
		{
			notifications.setIdAgenda(c.getInt(c.getColumnIndex(KEY_ID_AGENDA)));
			notifications.setTitre(c.getString(c.getColumnIndex(KEY_TITRE_NOTIFICATION)));
			notifications.setDescription(c.getString(c.getColumnIndex(KEY_DESCRIPTION_NOTIFICATION)));
			notifications.setdate_debut_event(c.getString(c.getColumnIndex(KEY_DATE_DEBUT_EVENT)));			
			int a=Integer.parseInt(c.getString(c.getColumnIndex(KEY_EVENEMENT_ID)));			
			
			}
		c.close();
		return notifications;
	}
	
	//
	public List<Notifications> listNotification() {
		List<Notifications> listes = new ArrayList<Notifications>();
		Notifications noti;
		Cursor curs = bdd.rawQuery("SELECT * FROM " + TABLE_NAME, null);
		if (curs.moveToFirst()) {
			do {
				noti = new Notifications();
				noti.setIdAgenda(curs.getInt(curs.getColumnIndex(KEY_ID_AGENDA)));
				noti.setTitre(curs.getString(curs.getColumnIndex(KEY_TITRE_NOTIFICATION)));				
				noti.setDescription(curs.getString(curs.getColumnIndex(KEY_DESCRIPTION_NOTIFICATION)));
				noti.setdate_debut_event(curs.getString(curs.getColumnIndex(KEY_DATE_DEBUT_EVENT)));
				
				listes.add(noti);
			} while (curs.moveToNext());
		}
		curs.close();
		return listes;
	}
	
	//recherche par titre de la notification
	public Notifications getTitreNotification(String titre)
	{
		Notifications notifications=new Notifications();
		
		Cursor c=bdd.rawQuery("SELECT * FROM "+TABLE_NAME+" WHERE "+KEY_TITRE_NOTIFICATION+ " = " +titre, null);
		if(c.moveToFirst())
		{
			notifications.setIdAgenda(c.getInt(c.getColumnIndex(KEY_ID_AGENDA)));
			notifications.setTitre(c.getString(c.getColumnIndex(KEY_TITRE_NOTIFICATION)));
			notifications.setDescription(c.getString(c.getColumnIndex(KEY_DESCRIPTION_NOTIFICATION)));
			notifications.setdate_debut_event(c.getString(c.getColumnIndex(KEY_DATE_DEBUT_EVENT)));			
			int a=Integer.parseInt(c.getString(c.getColumnIndex(KEY_EVENEMENT_ID)));
			
			}
		c.close();
		return notifications;
	}
	
	public Cursor getListNotification()
	{
		return bdd.rawQuery("SELECT * FROM "+TABLE_NAME, null);
	}

}
