package Dao;

import com.example.agendaevoluer.*;

import Entity.Utilisateur;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class UtilisateurDao {
	
	
public static final String TABLE_NAME="Utilisateur";
	public static final String KEY_ID_UTILISATEUR="id_user";
	public static final String KEY_NOM_UTILISATEUR="nom";
	public static final String KEY_PRENOM_UTILISATEUR="prenom";
	public static final String KEY_EMAIL_UTILISATEUR="email";
	
	private SQLiteDatabase bdd;
	private DatabaseHelper maBaseSqLite;
	
	
	public UtilisateurDao(Context context)
	{
		maBaseSqLite=DatabaseHelper.getInstance(context);
	}
	
	public static final String CREATE_TABLE_UTILISATEUR=" ";
	public void open()
	{
		bdd=maBaseSqLite.getWritableDatabase();
	}
	
	public void close()
	{
		bdd.close();
	}
	
	public long AjouterUtilisateur(Utilisateur utilisateur)
	{
		ContentValues values=new ContentValues();
		values.put(KEY_ID_UTILISATEUR, utilisateur.getIduser());
		values.put(KEY_NOM_UTILISATEUR,utilisateur.getNom());
		values.put(KEY_PRENOM_UTILISATEUR,utilisateur.getPrenom());
		values.put(KEY_EMAIL_UTILISATEUR,utilisateur.getEmail());
		
		return bdd.insert(TABLE_NAME, null, values);
	}
	
	/*public int ModifierUtilisateur(Utilisateur utilisateur)
	{
		ContentValues values=new ContentValues();
		values.put(KEY_NOM_UTILISATEUR,utilisateur.getNom());
		values.put(KEY_PRENOM_UTILISATEUR,utilisateur.getPrenom());
		values.put(KEY_EMAIL_UTILISATEUR,utilisateur.getEmail());
		String where=KEY_ID_UTILISATEUR+" = ?";
		String[] whereArgs={utilisateur.getIduser()+""};
		return bdd.update(TABLE_NAME, values, where, whereArgs);
	}
	
	public int SupprimerUtilisateur(Utilisateur utilisateur)
	{
		String where = KEY_ID_UTILISATEUR+ " = ?";
		String[] whereArgs = {utilisateur.getIduser()+ ""};
		return bdd.delete(TABLE_NAME,where, whereArgs);
	}
	*/
	public Utilisateur getUtilisateur(int id)
	{
		Utilisateur utilisateur=new Utilisateur();
		
		Cursor c=bdd.rawQuery("SELECT * FROM "+TABLE_NAME+" WHERE "+KEY_ID_UTILISATEUR+"="+id, null);
		if(c.moveToFirst())
		{
			utilisateur.setIduser(c.getInt(c.getColumnIndex(KEY_ID_UTILISATEUR)));
			utilisateur.setNom(c.getString(c.getColumnIndex(KEY_NOM_UTILISATEUR)));
			utilisateur.setPrenom(c.getString(c.getColumnIndex(KEY_PRENOM_UTILISATEUR)));
			utilisateur.setEmail(c.getString(c.getColumnIndex(KEY_EMAIL_UTILISATEUR)));			
			}
		c.close();
		return utilisateur;
	}
	
	//recherche par nom
	public Utilisateur getNomUtilisateur(String nom)
	{
		Utilisateur utilisateur=new Utilisateur();
		
		Cursor c=bdd.rawQuery("SELECT * FROM "+TABLE_NAME+" WHERE "+KEY_NOM_UTILISATEUR+ " = " +nom, null);
		if(c.moveToFirst())
		{
			utilisateur.setIduser(c.getInt(c.getColumnIndex(KEY_ID_UTILISATEUR)));
			utilisateur.setNom(c.getString(c.getColumnIndex(KEY_NOM_UTILISATEUR)));
			utilisateur.setPrenom(c.getString(c.getColumnIndex(KEY_PRENOM_UTILISATEUR)));
			utilisateur.setEmail(c.getString(c.getColumnIndex(KEY_EMAIL_UTILISATEUR)));	
			
			}
		c.close();
		return utilisateur;
	}
	
	public Cursor getListUtilisateur()
	{
		return bdd.rawQuery("SELECT * FROM "+TABLE_NAME, null );
	}
	
	//methode pour verifier si y a moins une ligne de donnee dans le table Utilisateur
	public boolean estVide() {		
		boolean verifier;
		Cursor c=bdd.rawQuery("SELECT * FROM "+TABLE_NAME,null);
		if(c!=null && c.getCount()>0) {
			//si y a aucune donnee dans le table Utilisateur
			//on met true
			verifier=false;
		}
		else {
			//sion false
			verifier=true;
		}
		c.close();
		return verifier;
		
	}

}
