package Dao;


import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.example.agendaevoluer.*;

import Entity.Evenement;
import android.app.Notification;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;


public class EvenementDao {

	public static final String TABLE_NAME="Evenement";
	public static final String KEY_ID_EVENEMENT="id_event";
	public static final String KEY_TITRE_EVENEMENT="titre_event";	
	public static final String KEY_TYPE_EVENEMENT="type";
	public static final String KEY_DATE_DEBUT_EVENEMENT="date_debut";
	public static final String KEY_DATE_FIN_EVENEMENT="date_fin";	
	public static final String KEY_LIEU_EVENEMENT="lieu";
	public static final String KEY_DESCRIPTION_EVENEMENT="description";	
	public static final String KEY_ALERTE_EVENEMENT="alerte";
	//public static final String KEY_UTILISATEUR_ID_EVENEMENT="Utilisateur_id";
	
	//pour les attributs pour la notification
	 /*public static final String TABLE_NAME2="Notification";
		public static final String KEY_ID_AGENDA="id_agenda";
		public static final String KEY_TITRE_NOTIFICATION="titre";
		public static final String KEY_DESCRIPTION_NOTIFICATION="description";
		public static final String KEY_DATE_DEBUT_EVENT="date_debut";
		public static final String KEY_EVENEMENT_ID="Evenement_id";	*/
		
	private SQLiteDatabase bdd;
	private DatabaseHelper maBaseSqLite;
	
	//pour le dao d'evenement
	public EvenementDao(Context context)
	{
		maBaseSqLite=DatabaseHelper.getInstance(context);
	}
		
	public static final String CREATE_TABLE_EVENEMENT=" ";
	//pour la ouverture de la base de donnee
	public void open()
	{
		bdd=maBaseSqLite.getWritableDatabase();
	}
	//pour la fermeture de la base de donnee
	public void close()
	{
		bdd.close();
	}
	
	public long AjouterEvenement(Evenement evenement) throws ParseException
	{
		//pour transformer Date en String
		String debut=(evenement.getDate_debut().toString());
	      String fin=(evenement.getDate_fin().toString());	      

		ContentValues values=new ContentValues();
		values.put(KEY_ID_EVENEMENT,evenement.getIdEve());
		values.put(KEY_TITRE_EVENEMENT,evenement.getTitre());		
		values.put(KEY_TYPE_EVENEMENT, evenement.getType());
		values.put(KEY_DATE_DEBUT_EVENEMENT,evenement.getDate_debut());
		values.put(KEY_DATE_FIN_EVENEMENT,evenement.getDate_fin());		
		values.put(KEY_LIEU_EVENEMENT,evenement.getLieu());
		values.put(KEY_DESCRIPTION_EVENEMENT,evenement.getDescription());
		values.put(KEY_ALERTE_EVENEMENT, evenement.getAlerte());
		//values.put(KEY_UTILISATEUR_ID_EVENEMENT,evenement.getUtilisateur_id());		
		//values.put(KEY_IDFILIERE_ETUDIANT,etudiant.getIdfiliere());
		
		/*//Pour transformer String en date
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = null;
		date = (Date) dateFormat.parse(evenement.getDate_debut());
		//Date date=evenement.getDate_debut();		
		date.setHours(date.getHours());        

        //int id_event=event_id;
        ContentValues value = new ContentValues();
        Notification notifi=new Notification();
        value.put(KEY_TITRE_NOTIFICATION,evenement.getTitre());
        value.put(KEY_DESCRIPTION_NOTIFICATION,evenement.getDescription());
        //pour recuperer l'id de l'evenement
        value.put(KEY_ID_EVENEMENT,evenement.getIdEve());
        value.put(KEY_DATE_DEBUT_EVENT,date.toString());
        //return  event_id = db.insert(TABLE_Notification, null, value);
        bdd.insert(TABLE_NAME2, null, values);*/
        return bdd.insert(TABLE_NAME, null, values);

	}
	
	public int ModifierEvenement(Evenement evenement)
	{
		//pour transformer Date en String	   
	    
		ContentValues values=new ContentValues();
		values.put(KEY_TITRE_EVENEMENT,evenement.getTitre());
		values.put(KEY_DATE_DEBUT_EVENEMENT,evenement.getDate_debut().toString());
		values.put(KEY_DATE_FIN_EVENEMENT,evenement.getDate_fin().toString());		
		values.put(KEY_LIEU_EVENEMENT,evenement.getLieu());
		values.put(KEY_TYPE_EVENEMENT, evenement.getType());
		values.put(KEY_DESCRIPTION_EVENEMENT,evenement.getDescription());
		values.put(KEY_ALERTE_EVENEMENT, evenement.getAlerte());
		String where=KEY_ID_EVENEMENT+" = ?";
		String[] whereArgs={evenement.getIdEve()+""};
		return bdd.update(TABLE_NAME, values, where, whereArgs);
	}
	
	public boolean updateData(String id,String titre,String dateDebut,String dateFin,String lieu,String type,String description,String alerte) {
        
        ContentValues contentValues = new ContentValues();
        contentValues.put(KEY_ID_EVENEMENT,id);
        contentValues.put(KEY_TITRE_EVENEMENT,titre);
        contentValues.put(KEY_LIEU_EVENEMENT,lieu);
        contentValues.put(KEY_DATE_DEBUT_EVENEMENT,dateDebut);
        contentValues.put(KEY_DATE_FIN_EVENEMENT,dateFin);
        contentValues.put(KEY_TYPE_EVENEMENT,type);
        contentValues.put(KEY_DESCRIPTION_EVENEMENT,description);
        contentValues.put(KEY_ALERTE_EVENEMENT,alerte);
        
        bdd.update(TABLE_NAME, contentValues, "KEY_ID_EVENEMENT = ?",new String[] { id });
        return true;
    }
	
	public int SupprimerEvenement(Evenement evenement)
	{
		String where = KEY_ID_EVENEMENT+ " = ?";
		String[] whereArgs = {evenement.getIdEve()+ ""};
		return bdd.delete(TABLE_NAME,where, whereArgs);
	}
	
	public Evenement getEvenement(int id)
	{
		
		Evenement evenement=new Evenement();
				
		Cursor c=bdd.rawQuery("SELECT * FROM "+TABLE_NAME+" WHERE "+KEY_ID_EVENEMENT+"="+id, null);
		if(c.moveToFirst())
		{
			evenement.setIdEve(c.getInt(c.getColumnIndex(KEY_ID_EVENEMENT)));
			evenement.setTitre(c.getString(c.getColumnIndex(KEY_TITRE_EVENEMENT)));		
			evenement.setDate_debut(c.getString(c.getColumnIndex(KEY_DATE_DEBUT_EVENEMENT)));			
			evenement.setDate_fin(c.getString(c.getColumnIndex(KEY_DATE_FIN_EVENEMENT)));			
			evenement.setLieu(c.getString(c.getColumnIndex(KEY_LIEU_EVENEMENT)));
			evenement.setDescription(c.getString(c.getColumnIndex(KEY_DESCRIPTION_EVENEMENT)));
			evenement.setType(c.getString(c.getColumnIndex(KEY_TYPE_EVENEMENT)));
			evenement.setAlerte(c.getString(c.getColumnIndex(KEY_ALERTE_EVENEMENT)));
			//pour la relation entre Evenement et l'utilisateur
			//int a=Integer.parseInt(c.getString(c.getColumnIndex(KEY_UTILISATEUR_ID_EVENEMENT)));
			
			}
		c.close();
		return evenement;
	}
	
	//
	public List<Evenement> listEvenement() {
		List<Evenement> listes = new ArrayList<Evenement>();
		Evenement ev;
		Cursor curs = bdd.rawQuery("SELECT * FROM " + TABLE_NAME, null);
		if (curs.moveToFirst()) {
			do {
				ev = new Evenement();
				ev.setIdEve(curs.getInt(curs.getColumnIndex(KEY_ID_EVENEMENT)));
				ev.setTitre(curs.getString(curs.getColumnIndex(KEY_TITRE_EVENEMENT)));
				ev.setLieu(curs.getString(curs.getColumnIndex(KEY_LIEU_EVENEMENT)));
				ev.setDescription(curs.getString(curs.getColumnIndex(KEY_DESCRIPTION_EVENEMENT)));
				ev.setDate_debut(curs.getString(curs.getColumnIndex(KEY_DATE_DEBUT_EVENEMENT)));
				ev.setDate_fin(curs.getString(curs.getColumnIndex(KEY_DATE_FIN_EVENEMENT)));
				ev.setAlerte(curs.getString(curs.getColumnIndex(KEY_ALERTE_EVENEMENT)));
				listes.add(ev);
			} while (curs.moveToNext());
		}
		curs.close();
		return listes;
	}
	
	//recherche par titre d'evenement
	public Evenement getTitreEvenement(String titre)
	{
		Evenement evenement=new Evenement();
		
		Cursor c=bdd.rawQuery("SELECT * FROM "+TABLE_NAME+" WHERE "+KEY_TITRE_EVENEMENT+ " = " +titre, null);
		if(c.moveToFirst())
		{
			evenement.setIdEve(c.getInt(c.getColumnIndex(KEY_ID_EVENEMENT)));
			evenement.setTitre(c.getString(c.getColumnIndex(KEY_TITRE_EVENEMENT)));				
			evenement.setDate_debut(c.getString(c.getColumnIndex(KEY_DATE_DEBUT_EVENEMENT)));
			evenement.setDate_fin(c.getString(c.getColumnIndex(KEY_DATE_FIN_EVENEMENT)));
			
			evenement.setLieu(c.getString(c.getColumnIndex(KEY_LIEU_EVENEMENT)));
			evenement.setDescription(c.getString(c.getColumnIndex(KEY_DESCRIPTION_EVENEMENT)));
			evenement.setAlerte(c.getString(c.getColumnIndex(KEY_ALERTE_EVENEMENT)));
			//pour la relation entre Evenement et l'utilisateur
			//int a=Integer.parseInt(c.getString(c.getColumnIndex(KEY_UTILISATEUR_ID_EVENEMENT)));
			
			}
		c.close();
		return evenement;
	}
	
	//pour afficher tous les evenements	
	public Cursor getListEvenement()
	{
		return bdd.rawQuery("SELECT * FROM "+TABLE_NAME, null);
	}
}
