package com.example.agendaevoluer;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import Dao.EvenementDao;
import Dao.NotificationDao;
import Entity.Evenement;
import Entity.Notifications;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.Intent;
import android.database.Cursor;
import android.net.ParseException;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

public class ModifierEvent extends Activity {
	
	//pour recupere info via Intent
	String id_event;
	Intent intentesource = null;
	
	 //list pour le type d'evenement
		String[] list= {
				"",
				"Particulier",
				"Professionnel"
		};
		//
		String[] listAlert= {			
				"A l'heure de l'�v�nement",//=0
				"5 minutes avant",        //=1
				"15 minutes avant",       //=2
				"30 minutes avant",       //=3
				"1 heure avant",          //=4
				"2 heures avant",         //=5
				"1 jour avant",           //=6
				"2 jours avant",          //=7
				"1 semaine avant"         //=8
		};
		Spinner spinnerType,spinnerAlerte;
		//declaration des attributs
		TextView tvTitre,tvDate_debut,tvDate_fin,tvInterval,tvLieu,tvDescription;
		Button btnModifier, btnAnnuler;
		int annee,mois,jour,heur,minute;
		//infos recues
		//String dateInfos,timeInfos;
		String dateTimeInfos,dateInfos;
		private SimpleDateFormat mSimpleDateFormat;
		private DateFormat df;
		private Calendar cal;
		
		///
		EvenementDao eventDao;
		List<Evenement> listEvents=new ArrayList<Evenement>();
		List<Long> listDateBebut = new ArrayList<Long>();
		Timestamp timestamp;
		private static final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy h:mm a");

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_modifier_event);
		
setTitle("Formulaire ");
        
		//on recupere l'info selon l'identifiant
		intentesource = getIntent();
		id_event=intentesource.getStringExtra("v_id");		
		//pour rappeler la classe MonService
		startService(new Intent(this, MonService.class));
		//testEvenement();
		//pour le type
		spinnerType=(Spinner)findViewById(R.id.spinnerType_m);
		spinnerAlerte=(Spinner)findViewById(R.id.spinnerAlert_m);
		//adapter pour le type
		ArrayAdapter<String> adapter=new ArrayAdapter<String>
		(this,android.R.layout.simple_spinner_item, list);
		//adapter pour Alerte
		ArrayAdapter<String> adapter2=new ArrayAdapter<String>
		(this,android.R.layout.simple_spinner_item, listAlert);
		spinnerType.setAdapter(adapter);
		spinnerAlerte.setAdapter(adapter2);
		//affectation des differents champs du formulaire aux attributs de l'evenement
		tvTitre=(TextView)findViewById(R.id.editTextTitre_m);
		tvDate_debut=(TextView)findViewById(R.id.editTextDateDebut_m);
		tvDate_fin=(TextView)findViewById(R.id.editTextDateFin_m);
		//tvInterval=(TextView)findViewById(R.id.editTextIntervalTemps);
		tvLieu=(TextView)findViewById(R.id.editTextLieu_m);
		tvDescription=(TextView)findViewById(R.id.editTextDescription_m);
		//les bouttons
		btnModifier=(Button)findViewById(R.id.buttonModifier_m);
		btnAnnuler=(Button)findViewById(R.id.buttonAnnuler_m);
		
				
		//pour recuperer les valeurs de date debut et fin
		String date_debut,date_fin,dateInfos;
		mSimpleDateFormat = new SimpleDateFormat("dd/MM/yyyy h:mm a", Locale.getDefault());
		
		///
		eventDao=new EvenementDao(this);
		eventDao.open();
		Evenement event=eventDao.getEvenement(Integer.parseInt(id_event));
		eventDao.close();	
		tvTitre.setText(event.getTitre());
		tvLieu.setText(event.getLieu());
		tvDate_debut.setText(event.getDate_debut());
		tvDate_fin.setText(event.getDate_fin());		
		tvDescription.setText(event.getDescription());
	}
	
	//methode pour recuperer la date et l'heur saisie par l'utilisateur pour le champs DateDebut
		public void getDateTimeDebutInfos() {
			cal=Calendar.getInstance();
			annee=cal.get(Calendar.YEAR);
			mois=cal.get(Calendar.MONTH);
			jour=cal.get(Calendar.DATE);		
			
	      TimePickerDialog timepicker=new TimePickerDialog(ModifierEvent.this, new OnTimeSetListener() {
				
				@Override
				public void onTimeSet(TimePicker view, int _heur, int _minute) {
					// TODO Auto-generated method stub				
					//timeInfos=heur+" :"+minute;
					//String s = new SimpleDateFormat("MM/dd/yyyy").format(dateInfos+timeInfos);
					cal.set(Calendar.HOUR_OF_DAY, _heur);
		            cal.set(Calendar.MINUTE, _minute);
		            tvDate_debut.setText(mSimpleDateFormat.format(cal.getTime()));
				
				}
			}, heur, minute, false);
			timepicker.show();
			
	      DatePickerDialog datepicker=new DatePickerDialog(ModifierEvent.this, new OnDateSetListener() {
				
				@Override
				public void onDateSet(DatePicker view, int _annee, int _mois, int _jour) {
					// TODO Auto-generated method stub
					//dateInfos=jour+" /"+(mois+1)+" /"+annee;
					cal.set(Calendar.YEAR, _annee);
					cal.set(Calendar.MONTH, _mois);
					cal.set(Calendar.DAY_OF_MONTH, _jour);
					//dateInfos=_jour + "-" + (_mois + 1) + "-" + _annee;
					//tvDate_debut.setText(dateInfos);
					
				}
			}, annee, mois, jour);
			datepicker.show();
			
			
		}
		//methode pour recuperer la date et l'heur saisie par l'utilisateur pour le champs DateFin
		public void getDateTimeFinInfos(){
			
			cal=Calendar.getInstance();
			annee=cal.get(Calendar.YEAR);
			mois=cal.get(Calendar.MONTH);
			jour=cal.get(Calendar.DATE);		
			
	      TimePickerDialog timepicker=new TimePickerDialog(ModifierEvent.this, new OnTimeSetListener() {
				
				@Override
				public void onTimeSet(TimePicker view, int _heur, int _minute) {
					// TODO Auto-generated method stub				
					//timeInfos=heur+" :"+minute;
					//String s = new SimpleDateFormat("MM/dd/yyyy").format(dateInfos+timeInfos);
					cal.set(Calendar.HOUR_OF_DAY, _heur);
		            cal.set(Calendar.MINUTE, _minute);
		           
		            tvDate_fin.setText(mSimpleDateFormat.format(cal.getTime()));       
		            
				
				}
			}, heur, minute, false);
			timepicker.show();
			
			
			
	      DatePickerDialog datepicker=new DatePickerDialog(ModifierEvent.this, new OnDateSetListener() {
				
				@Override
				public void onDateSet(DatePicker view, int _annee, int _mois, int _jour) {
					// TODO Auto-generated method stub
					//dateInfos=jour+" /"+(mois+1)+" /"+annee;
					cal.set(Calendar.YEAR, _annee);
					cal.set(Calendar.MONTH, _mois);
					cal.set(Calendar.DAY_OF_MONTH, _jour);
					//dateInfos=_jour + "-" + (_mois + 1) + "-" + _annee;
					//tvDate_debut.setText(dateInfos);
					
				}
			}, annee, mois, jour);
			datepicker.show();
			
			
			
		}
		
		//metode pour recuperer les donnees date et heur par un clique dessus sur les champs dateDebut/dateFin
				
		public void clickDateDebut(View v) {
			getDateTimeDebutInfos();
		}
		
		public void clickDateFin(View v) {
			getDateTimeFinInfos();
		}
		
		//apres click bouton modifier
		public void clickModifier(View v) {
			modifer();
		}
		
		//methode pour modifer
		public void modifer() throws ParseException {
			// TODO Auto-generated method stub
			
			EvenementDao eventDao=new EvenementDao(this);
			NotificationDao notifiDao=new NotificationDao(this);
			Evenement event=new Evenement();
			Notifications notifi=new Notifications();
			//formatage du date 
			//SimpleDateFormat formeDate=new SimpleDateFormat("dd/M/YYYY");
			//On recupere les informations saisies dans le formulaire d'ajoute evenement
			String titre_event=tvTitre.getText().toString();
			String date_debut_event=tvDate_debut.getText().toString();
			String date_fin_event=tvDate_fin.getText().toString();
			//String interval_event=tvInterval.getText().toString();
			String lieu_event=tvLieu.getText().toString();
			String description_event=tvDescription.getText().toString();
			String type_event=spinnerType.getSelectedItem().toString();
			//int myalerte=(int) spinnerAlerte.getSelectedItemId();
			String myalerte=spinnerAlerte.getSelectedItem().toString();
			//Evenement event=new Evenement();
			//Pour transformer String en date
			//SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			//Date date = null;
//			try {
//				//date = (Date) dateFormat.parse(date_debut_event);
//			} catch (ParseException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//				System.out.println("Erreur de tranformation date");
//			}
			//Date date=evenement.getDate_debut();		
			//date.setHours(date.getHours());        
			
			
			//Date datedebut=(Date) mSimpleDateFormat.parse(date_debut_event);
			//Date datefin=(Date) mSimpleDateFormat.parse(date_fin_event);
		
			//Timestamp timestampDebut = new Timestamp(datedebut.getTime());
			//Timestamp timestampFin = new Timestamp(datefin.getTime());
			
			/*public void modifier(View v){
				
				
				mydao.open();
				
				
				ets.setId(myid);
				ets.setNom(""+pname.getText());
				ets.setTelephone(""+ptel.getText());
				ets.setAdresse(""+padresse.getText());
				ets.setEmail(""+pmail.getText());
				
				mydao.modifierEtudiant(ets);
				
					
				mydao.close();
			}
			*/
			if(!titre_event.isEmpty() && !date_debut_event.isEmpty() && !date_fin_event.isEmpty() && !lieu_event.isEmpty() 
					&& !description_event.isEmpty()){
				
				 boolean isUpdate = eventDao.updateData(id_event,titre_event,lieu_event,date_debut_event,
                         date_fin_event,type_event,description_event,myalerte);
                 if(isUpdate == true)
                     Toast.makeText(ModifierEvent.this,"Data Update",Toast.LENGTH_LONG).show();
                 else
                     Toast.makeText(ModifierEvent.this,"Data not Updated",Toast.LENGTH_LONG).show();
             
			/*
			eventDao.open();
			notifiDao.open();
			event.setTitre(titre_event);
			event.setLieu(lieu_event);
			event.setDate_debut(date_debut_event);
			event.setDate_fin(date_fin_event);
			event.setDescription(description_event);
			event.setAlerte(date_fin_event);
			event.setType(type_event);
			
			eventDao.ModifierEvenement(event);
			eventDao.close();
			
			notifi.setTitre(titre_event);
			notifi.setdate_debut_event(date_debut_event);
			notifi.setDescription(description_event);
			
			notifiDao.ModifierNotification(notifi);
			notifiDao.close();*/
			
			/*//on cree un curseur pour recuperer de donnee dans la table evement si il y on a
			Cursor c=eventDao.getListEvenement();
			int _id = 0;
			if(c.moveToFirst()){
				do{   //on recupere la derniere identifiant 
					_id=c.getInt(c.getColumnIndex(EvenementDao.KEY_ID_EVENEMENT));
				}
				while(c.moveToNext());
			}
					    //on rajoute "+1" la derniere identifiant 
						int id_suivant=_id+1;
						//ajoute d'evenement						
						
						eventDao.ModifierEvenement(new Evenement(id_suivant,titre_event,date_debut_event,date_fin_event,lieu_event,type_event,description_event,myalerte));
						//ajoute de la notification en parallele 
						//notifiDao.ModifierNotification(new Notifications())
			            notifiDao.AjouterNotification(new Notifications(id_suivant,titre_event,description_event,date_debut_event,id_suivant));
						
					
					
					//Succes lors de l'ajouter de l'evenement
					Toast.makeText(this,"Modification avec success!",Toast.LENGTH_LONG).show();
					//methode pour lancer l'alarme
					//verifierAlarm();
				
				
			eventDao.close();		
			notifiDao.close();	
			c.close();//fermeture du curseur
*/			
			}
			else{
				//en cas d'echec
				Toast.makeText(this,"Certains champs sont vides,veuillez les remplir!",Toast.LENGTH_LONG).show();
			}
			
			/*Intent intent = new Intent(Inscription.this,MainActivity.class);
			intent.putExtra("varlogin", getTitle());
			startActivity(intent);*/
		
		}

    
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.modifier_event, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
