package com.example.agendaevoluer;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import Dao.EvenementDao;
import Dao.NotificationDao;
import Dao.UtilisateurDao;
import Entity.Evenement;
import Entity.Notifications;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

public class EventAddForm extends Activity implements OnClickListener {
    //list pour le type d'evenement
	String[] list= {
			"",
			"Particulier",
			"Professionnel"
	};
	//
	String[] listAlert= {			
			"A l'heure de l'�v�nement",//=0
			"5 minutes avant",        //=1
			"15 minutes avant",       //=2
			"30 minutes avant",       //=3
			"1 heure avant",          //=4
			"2 heures avant",         //=5
			"1 jour avant",           //=6
			"2 jours avant",          //=7
			"1 semaine avant"         //=8
	};
	Spinner spinnerType,spinnerAlerte;
	//declaration des attributs
	TextView tvTitre,tvDate_debut,tvDate_fin,tvInterval,tvLieu,tvDescription;
	Button btnAjouter, btnAnnuler;
	int annee,mois,jour,heur,minute;
	//infos recues
	//String dateInfos,timeInfos;
	String dateTimeInfos,dateInfos;
	private SimpleDateFormat mSimpleDateFormat;
	private DateFormat df;
	private Calendar cal;
	
	///
	EvenementDao eventDao;
	List<Evenement> listEvents=new ArrayList<Evenement>();
	List<Long> listDateBebut = new ArrayList<Long>();
	Timestamp timestamp;
	private static final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy h:mm a");
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_event_add_form);
		setTitle("Formulaire ");
		//pour rappeler la classe MonService
		startService(new Intent(this, MonService.class));
		//testEvenement();
		//pour le type
		spinnerType=(Spinner)findViewById(R.id.spType);
		spinnerAlerte=(Spinner)findViewById(R.id.spinnerAlert);
		//adapter pour le type
		ArrayAdapter<String> adapter=new ArrayAdapter<String>
		(this,android.R.layout.simple_spinner_item, list);
		//adapter pour Alerte
		ArrayAdapter<String> adapter2=new ArrayAdapter<String>
		(this,android.R.layout.simple_spinner_item, listAlert);
		spinnerType.setAdapter(adapter);
		spinnerAlerte.setAdapter(adapter2);
		//affectation des differents champs du formulaire aux attributs de l'evenement
		tvTitre=(TextView)findViewById(R.id.editTextTitre);
		tvDate_debut=(TextView)findViewById(R.id.editTextDateDebut);
		tvDate_fin=(TextView)findViewById(R.id.editTextDateFin);
		//tvInterval=(TextView)findViewById(R.id.editTextIntervalTemps);
		tvLieu=(TextView)findViewById(R.id.editTextLieu);
		tvDescription=(TextView)findViewById(R.id.editTextDescription);
		//les bouttons
		btnAjouter=(Button)findViewById(R.id.imageBtnAjouter);
		btnAnnuler=(Button)findViewById(R.id.buttonAnnuler);
		
		//pour la date et time 
		tvDate_debut.setOnClickListener(this);
		tvDate_fin.setOnClickListener(this);
		
		//pour recuperer les valeurs de date debut et fin
		String date_debut,date_fin,dateInfos;
		mSimpleDateFormat = new SimpleDateFormat("dd/MM/yyyy h:mm a", Locale.getDefault());
		
		
	}
	
	//methode pour ajouter un evenement 
	public void AjouterEvent(View v) throws ParseException {
		Ajouter();
	}
	
	//methode pour annuler
	public void AnnulerEvent(View v) {
		testEvenement();
	}
	//methode pour recuperer la date et l'heur saisie par l'utilisateur pour le champs DateDebut
	public void getDateTimeDebutInfos() {
		cal=Calendar.getInstance();
		annee=cal.get(Calendar.YEAR);
		mois=cal.get(Calendar.MONTH);
		jour=cal.get(Calendar.DATE);		
		
      TimePickerDialog timepicker=new TimePickerDialog(EventAddForm.this, new OnTimeSetListener() {
			
			@Override
			public void onTimeSet(TimePicker view, int _heur, int _minute) {
				// TODO Auto-generated method stub				
				//timeInfos=heur+" :"+minute;
				//String s = new SimpleDateFormat("MM/dd/yyyy").format(dateInfos+timeInfos);
				cal.set(Calendar.HOUR_OF_DAY, _heur);
	            cal.set(Calendar.MINUTE, _minute);
	            tvDate_debut.setText(mSimpleDateFormat.format(cal.getTime()));
			
			}
		}, heur, minute, false);
		timepicker.show();
		
      DatePickerDialog datepicker=new DatePickerDialog(EventAddForm.this, new OnDateSetListener() {
			
			@Override
			public void onDateSet(DatePicker view, int _annee, int _mois, int _jour) {
				// TODO Auto-generated method stub
				//dateInfos=jour+" /"+(mois+1)+" /"+annee;
				cal.set(Calendar.YEAR, _annee);
				cal.set(Calendar.MONTH, _mois);
				cal.set(Calendar.DAY_OF_MONTH, _jour);
				//dateInfos=_jour + "-" + (_mois + 1) + "-" + _annee;
				//tvDate_debut.setText(dateInfos);
				
			}
		}, annee, mois, jour);
		datepicker.show();
		
		
	}
	//methode pour recuperer la date et l'heur saisie par l'utilisateur pour le champs DateFin
	public void getDateTimeFinInfos(){
		
		cal=Calendar.getInstance();
		annee=cal.get(Calendar.YEAR);
		mois=cal.get(Calendar.MONTH);
		jour=cal.get(Calendar.DATE);		
		
      TimePickerDialog timepicker=new TimePickerDialog(EventAddForm.this, new OnTimeSetListener() {
			
			@Override
			public void onTimeSet(TimePicker view, int _heur, int _minute) {
				// TODO Auto-generated method stub				
				//timeInfos=heur+" :"+minute;
				//String s = new SimpleDateFormat("MM/dd/yyyy").format(dateInfos+timeInfos);
				cal.set(Calendar.HOUR_OF_DAY, _heur);
	            cal.set(Calendar.MINUTE, _minute);
	           
	            tvDate_fin.setText(mSimpleDateFormat.format(cal.getTime()));       
	            
			
			}
		}, heur, minute, false);
		timepicker.show();
		
      DatePickerDialog datepicker=new DatePickerDialog(EventAddForm.this, new OnDateSetListener() {
			
			@Override
			public void onDateSet(DatePicker view, int _annee, int _mois, int _jour) {
				// TODO Auto-generated method stub
				//dateInfos=jour+" /"+(mois+1)+" /"+annee;
				cal.set(Calendar.YEAR, _annee);
				cal.set(Calendar.MONTH, _mois);
				cal.set(Calendar.DAY_OF_MONTH, _jour);
				//dateInfos=_jour + "-" + (_mois + 1) + "-" + _annee;
				//tvDate_debut.setText(dateInfos);
				
			}
		}, annee, mois, jour);
		datepicker.show();
	}
	//metode pour recuperer les donnees date et heur par un clique dessus sur les champs dateDebut/dateFin
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId()==R.id.editTextDateDebut) {			
			
			getDateTimeDebutInfos();
		}
		if(v.getId()==R.id.editTextDateFin) {
			getDateTimeFinInfos();
		}
	}

	//pour 
		public void Ajouter() throws ParseException {
			// TODO Auto-generated method stub
			
			EvenementDao eventDao=new EvenementDao(this);
			NotificationDao notifiDao=new NotificationDao(this);
			Evenement event=new Evenement();
			//formatage du date 
			//SimpleDateFormat formeDate=new SimpleDateFormat("dd/M/YYYY");
			//On recupere les informations saisies dans le formulaire d'ajoute evenement
			String titre_event=tvTitre.getText().toString();
			String date_debut_event=tvDate_debut.getText().toString();
			String date_fin_event=tvDate_fin.getText().toString();
			//String interval_event=tvInterval.getText().toString();
			String lieu_event=tvLieu.getText().toString();
			String description_event=tvDescription.getText().toString();
			String type_event=spinnerType.getSelectedItem().toString();
			//int myalerte=(int) spinnerAlerte.getSelectedItemId();
			String myalerte=spinnerAlerte.getSelectedItem().toString();
			//Evenement event=new Evenement();
			//Pour transformer String en date
			//SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			//Date date = null;
//			try {
//				//date = (Date) dateFormat.parse(date_debut_event);
//			} catch (ParseException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//				System.out.println("Erreur de tranformation date");
//			}
			//Date date=evenement.getDate_debut();		
			//date.setHours(date.getHours());        
			
			
			//Date datedebut=(Date) mSimpleDateFormat.parse(date_debut_event);
			//Date datefin=(Date) mSimpleDateFormat.parse(date_fin_event);
		
			//Timestamp timestampDebut = new Timestamp(datedebut.getTime());
			//Timestamp timestampFin = new Timestamp(datefin.getTime());
			
			if(!titre_event.isEmpty() && !date_debut_event.isEmpty() && !date_fin_event.isEmpty() && !lieu_event.isEmpty() 
					&& !description_event.isEmpty()){
				
			eventDao.open();   
			notifiDao.open();
			//on cree un curseur pour recuperer de donnee dans la table evement si il y on a
			Cursor c=eventDao.getListEvenement();
			int _id = 0;
			if(c.moveToFirst()){
				do{   //on recupere la derniere identifiant 
					_id=c.getInt(c.getColumnIndex(EvenementDao.KEY_ID_EVENEMENT));
				}
				while(c.moveToNext());
			}
					    //on rajoute "+1" la derniere identifiant 
						int id_suivant=_id+1;
						//ajoute d'evenement						
						eventDao.AjouterEvenement(new Evenement(id_suivant,titre_event,date_debut_event,date_fin_event,lieu_event,type_event,description_event,myalerte));
						//ajoute de la notification en parallele 
			            notifiDao.AjouterNotification(new Notifications(id_suivant,titre_event,description_event,date_debut_event,id_suivant));
						
					
					
					//Succes lors de l'ajouter de l'evenement
					Toast.makeText(this,"Insertion avec success!",Toast.LENGTH_LONG).show();
					//methode pour lancer l'alarme
					verifierAlarm();
				
				
			eventDao.close();		
			notifiDao.close();	
			c.close();//fermeture du curseur
			
			}
			else{
				//en cas d'echec
				Toast.makeText(this,"Certains champs sont vides,veuillez les remplir!",Toast.LENGTH_LONG).show();
			}
			
			/*Intent intent = new Intent(Inscription.this,MainActivity.class);
			intent.putExtra("varlogin", getTitle());
			startActivity(intent);*/
		
		}

public void testEvenement(){
		
		EvenementDao m=new EvenementDao(this);
		m.open();
		//m.AjouterUtilisateur(new Utilisateur(1,"HASSAN","Mouktar","mowlide10@gmail.com"));
				
		Cursor c=m.getListEvenement();
		if(c.moveToFirst()){
			do{
				int _id=c.getInt(c.getColumnIndex(EvenementDao.KEY_ID_EVENEMENT));
				String _titre=c.getString(c.getColumnIndex(EvenementDao.KEY_TITRE_EVENEMENT));
				String _date_debut=c.getString(c.getColumnIndex(EvenementDao.KEY_DATE_DEBUT_EVENEMENT));
				String _date_fin=c.getString(c.getColumnIndex(EvenementDao.KEY_DATE_FIN_EVENEMENT));				
				String _lieu=c.getString(c.getColumnIndex(EvenementDao.KEY_LIEU_EVENEMENT));
				String _description=c.getString(c.getColumnIndex(EvenementDao.KEY_DESCRIPTION_EVENEMENT));
				
				
				Toast.makeText(
						this,
						"Evenement de Test" + _id+ ","+ _titre+ "," + _date_debut + ","+_date_fin+","+_lieu+","+_description+"("
						+ _id + ")",Toast.LENGTH_LONG).show();
			}
			while(c.moveToNext());
		}
		c.close();//fermeture du curseur
		
		//fermeture du gestionnaire
		m.close();
	}



public void verifierAlarm() throws ParseException {
	
	eventDao=new EvenementDao(this);
	eventDao.open();
	listEvents=eventDao.listEvenement();
	eventDao.close();
	//on recupere la date du system local
	timestamp = new Timestamp(System.currentTimeMillis());
	//on formate le timestamp du system recuperee sous "dd/MM/yyyy h:mm a"
	String s = new SimpleDateFormat("dd/MM/yyyy h:mm a").format(timestamp);
	//on parse le timestamp en date selon notre format
	Date parsedDate1 = sdf.parse(s);
	//on caste notre date en time de type Long
	long currentTime=parsedDate1.getTime();
	//String localtime;
	//localtime=sdf.format(timestamp);
	for (Evenement ev : listEvents) {
		//conversion des donnees en Date
		Date parsedDate = sdf.parse(ev.getDate_debut());
		 long milli = parsedDate.getTime();
		 
		 listDateBebut.add(milli);			
	}
	//boucle pour verifier le registre des notification 
	//afin de lancer l'alarme
	for(int i=0;i<listDateBebut.size();i++) {
		long thistime=listDateBebut.get(i);
		//setAlarm(thistime);
		Toast.makeText(this,"OK!!!",Toast.LENGTH_SHORT).show();
		if(thistime==currentTime) {
			setAlarm(thistime);
		}
		else {
			Toast.makeText(this,"Pas encore!!!",Toast.LENGTH_SHORT).show();
		}
	}
	
	/*for(int i=0;i<mylistevent.size();i++) {
		if(mylistevent.contains(localtime)) {
			Toast.makeText(this,"Times up please!!!",Toast.LENGTH_LONG).show();
		}
	}*/
	
}

//methode pour lancer l'alarme
private void setAlarm(long temps) {
    //obtenir le gestionnaire d'alarme
    AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
    
    //cr�er une nouvelle intention sp�cifiant le r�cepteur de diffusion
    Intent i = new Intent(this, AlarmReceiver.class);
    
    //cr�er une intention en attente en utilisant l'intention
    PendingIntent pi = PendingIntent.getBroadcast(this, 0 , i, 0);
    
    //R�glage de l'alarme r�p�t�e qui sera d�clench�e a un temps choisis 
    //via AlarmManager.RTC_WAKEUP
    //am.setRepeating(AlarmManager.RTC, temps, AlarmManager.RTC_WAKEUP, pi);
    am.set(AlarmManager.RTC, temps,pi );
    Toast.makeText(this, "Alarm is set", Toast.LENGTH_SHORT).show();
}



	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.event_add_form, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

}
