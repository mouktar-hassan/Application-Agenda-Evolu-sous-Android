package com.example.agendaevoluer;

import java.util.ArrayList;
import java.util.List;

import Dao.EvenementDao;
import Entity.Evenement;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnClickListener;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class AfficherEvenement extends Activity {

	ListView listEvent;
	List<Evenement> listEvents=new ArrayList<Evenement>();
	Cursor eventCurseur;
	EvenementDao eventDao;
	List<String> mylistevent = new ArrayList<String>();
	List<String> listTitreEvent = new ArrayList<String>();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_afficher_evenement);
		
		afficherList();
		listEvent=(ListView)findViewById(R.id.listViewEvenements);
		
		
	    eventDao=new EvenementDao(this);		
	    
		
		ArrayAdapter<String> arrayAdapter  = new ArrayAdapter<String>(getApplicationContext(), 
				android.R.layout.simple_spinner_item,mylistevent);
		arrayAdapter.setDropDownViewResource(R.layout.activity_afficher_evenement);		
					listEvent.setAdapter(arrayAdapter);
					
					
					//code en construction
					listEvent.setOnItemClickListener(new OnItemClickListener() {
						
						@Override
						public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
							// TODO Auto-generated method stub
							String chaine;
							for(int i=0;i<listEvents.size();i++) {
								chaine=listEvents.get(i).getIdEve()+"\t\t "+listEvents.get(i).getTitre()+"\t\t "+
							listEvents.get(i).getLieu();
								if(chaine.equals(parent.getItemAtPosition(position))) {
									String _titre,_lieu,_dateDebut,_dateFin,_description,_alerte;
									long _idevent;
									_idevent=listEvents.get(i).getIdEve();
									_titre=listEvents.get(i).getTitre();
									_lieu=listEvents.get(i).getLieu();
									_dateDebut=listEvents.get(i).getDate_debut();
									_dateFin=listEvents.get(i).getDate_fin();
									_description=listEvents.get(i).getDescription();
									_alerte=listEvents.get(i).getAlerte();
									Intent myintent = new Intent(AfficherEvenement.this, DetailleEvenement.class);
									myintent.putExtra("v_id", ""+_idevent);
									myintent.putExtra("v_titre",_titre);
									myintent.putExtra("v_lieu",_lieu);
									myintent.putExtra("v_dateDebut",_dateDebut);
									myintent.putExtra("v_dateFin",_dateFin);
									myintent.putExtra("v_description",_description);
									myintent.putExtra("v_alerte",""+_alerte);
									startActivity(myintent);
									break;
								}
						
								
							}
							
						}
					});  //fin partie en construction
					
			

		
		
		
		
		
	}
	
	public void afficherList() {
		eventDao=new EvenementDao(this);
		eventDao.open();
		listEvents=eventDao.listEvenement();
		eventDao.close();
		for (Evenement ev : listEvents) {
			mylistevent.add(ev.getIdEve()+ "\t\t " + ev.getTitre() + "\t\t " + ev.getLieu());
			listTitreEvent.add(ev.getTitre());
		}
	}
	//code en construction 
	//methode pour afficher un dialog qui detaille un evenement cliquee dessus
	public void afficherDetaille(View v) {
		AlertDialog.Builder alertDialog=new AlertDialog.Builder(this);
		alertDialog.setTitle("Evenement");
		alertDialog.setIcon(R.drawable.event);
		
		alertDialog.setPositiveButton("Modifier", new OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				Toast.makeText(getApplicationContext(), "Vous cliquez sur Modifier", Toast.LENGTH_SHORT).show();
				
			}
		});
		
        alertDialog.setNeutralButton("Supprimer", new OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				Toast.makeText(getApplicationContext(), "Vous avez cliquez sur Supprimer", Toast.LENGTH_SHORT).show();
				
			}
		});

		alertDialog.setNegativeButton("Annuler", new OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				Toast.makeText(getApplicationContext(), "Vous avez cliquez sur Annuler", Toast.LENGTH_SHORT).show();
				
			}
		});	
		
		alertDialog.show();
	}//fin code en construction

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.afficher_evenement, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
