package com.example.agendaevoluer;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import Dao.EvenementDao;
import Dao.UtilisateurDao;
import Entity.Evenement;
import Entity.Utilisateur;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class UserAddForm extends Activity {
	
	//declaration des attributs
	TextView tvNom_user,tvPrenom_user,tvEmail_user;
	Button btnAjouter_user,btnAnnuler_user;
	
	//
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_user_add_form);
		tvNom_user=(TextView)findViewById(R.id.editTextNom_user);
		tvPrenom_user=(TextView)findViewById(R.id.editTextPrenom_user);
		tvEmail_user=(TextView)findViewById(R.id.editTextEmail_user);
		btnAjouter_user=(Button)findViewById(R.id.buttonAddUser);
		btnAnnuler_user=(Button)findViewById(R.id.buttonAnnuler_user);
				
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.user_add_form, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	//methode pour ajouter un utilisateur
	//cette methode est liee la vue (View) de la bouton "Ajouter" de la formulaire 
	//'ajout Utilisateur afin de lancer une action apres son clique
	public void AddUser(View v) throws ParseException {
		//rappelle de la methode dessous pour lancer dans la vue (View)
		InscrireUtilisateur();
		
		
	}
	
	//methode pour inscricre un utilisateur
	public void InscrireUtilisateur() throws ParseException {
		UtilisateurDao userDao=new UtilisateurDao(this);
		Utilisateur user=new Utilisateur();
		//On recupere les informations saisies dans le formulaire d'ajoute utilisateur
		String nom_user=tvNom_user.getText().toString();
		String prenom_user=tvPrenom_user.getText().toString();
		String email_user=tvEmail_user.getText().toString();
		//on verifie si certains champs de la formulaire  sont vide 
		if(!nom_user.isEmpty() && !prenom_user.isEmpty() && !email_user.isEmpty()) {
			userDao.open();
			//ici on a mis 1 pour l'ID utilisateur car un agenda aura seulement un et un seul
			//utilisateur (autrement dit le nombre d'un utilisateur par un agenda est limitee 
			//par 1
			userDao.AjouterUtilisateur(new Utilisateur(1,nom_user,prenom_user,email_user));
			//on ferme la base 
			userDao.close();
			//Succes lors de l'ajouter de l'evenement par un message dialogue
			Toast.makeText(this,"Insertion avec success!",Toast.LENGTH_LONG).show();
			
			//pour rediriger vers accueil activity
			Intent i=new Intent(UserAddForm.this,Accueil.class);
			startActivity(i);
		}
		else {
			//en cas d'echec
			Toast.makeText(this,"Certains champs sont vides,veuillez les remplir!",Toast.LENGTH_LONG).show();
		}
		
	}
	
	//methode pour la vue (View) du bouton "Annuler" de la formulaire
	public void AnnulerUser(View v ) {
		ViderChamps();
	}
	//methode pour vider less differents champs de la formulaire 
	public void ViderChamps() {
		tvNom_user.setText("");
		tvPrenom_user.setText("");
		tvEmail_user.setText("");
	}
	

}
