package com.example.agendaevoluer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.provider.Settings;
import android.util.Log;
import android.widget.Toast;
import android.app.Notification;
import android.app.Notification.Builder;

public class AlarmReceiver extends BroadcastReceiver{

	//la m�thode sera d�clench�e lorsque l'alarme est d�clench�e
    @Override
    public void onReceive(Context context, Intent intent) {
        
    	//vous pouvez v�rifier le journal qu'il est d�clench�
    	//Ici, nous ne faisons rien
    	//mais vous pouvez faire n'importe quelle t�che ici que vous voulez faire � un moment pr�cis tous les jours
        
        MediaPlayer media=MediaPlayer.create(context, Settings.System.DEFAULT_RINGTONE_URI);
        media.start();
    }

}
