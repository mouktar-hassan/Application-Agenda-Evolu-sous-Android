package com.example.agendaevoluer;

import Dao.EvenementDao;
import Dao.NotificationDao;
import Entity.Evenement;
import Entity.Notifications;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class DetailleNotification extends Activity {
	WebView webNoti;
	NotificationDao notifiDao;
	String id_noti;
	Intent intentesource = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_detaille_notification);
		
		webNoti=(WebView)findViewById(R.id.webViewNotification);
		WebSettings settings = webNoti.getSettings();
		settings.setDefaultTextEncodingName("utf-8");
		
		intentesource = getIntent();
		id_noti=intentesource.getStringExtra("v_id");
		
		AfficherDetaille();
	}
	
	//methode pour afficher
	private void AfficherDetaille() {
		notifiDao=new NotificationDao(this);
		notifiDao.open();
		Notifications notifi=notifiDao.getListNotification(Integer.parseInt(id_noti));
		notifiDao.close();		
		
		String mapage = "<form method=post ><TABLE BORDER=0 width=100%><TR><TH COLSPAN=4 BGCOLOR=cyan><FONT color=green>Les informations de la notification</font></TH></TR>"
				+ "<TR><TD ALIGN=right><FONT color=red>Titre :</font></TD> <TD  ALIGN=left>" + notifi.getTitre()
				+ "</TD> </TR>"
				+ "<TR><TD ALIGN=right><FONT color=red>Description :</font></TD> <TD COLSPAN=4  ALIGN=left>"
				+ notifi.getDescription() + "</TD> </TR>"
				+ "<TR><TD  ALIGN=right><FONT color=red>Date debut :</font></TD> <TD  COLSPAN=4 ALIGN=left>"
				+ notifi.getdate_debut_event()+ "</TD> </TR>";	
				

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.FROYO) {
			String base64 = Base64.encodeToString(mapage.getBytes(), Base64.DEFAULT);
			webNoti.loadData(base64, "text/html; charset=utf-8", "base64");
		} else {
			String header = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>";
			webNoti.loadData(header + mapage, "text/html; charset=UTF-8", null);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.detaille_notification, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
