package com.example.agendaevoluer;



import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

public class GeoLocalisation extends Activity {
	
	// Google Map
    private GoogleMap googleMap;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_geo_localisation);
		
try {
			
			// Loading map
			initilizeMap();
            //default map type
		    googleMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
			

			// Showing / hiding your current location
			googleMap.setMyLocationEnabled(true);

			// Enable / Disable zooming controls
			googleMap.getUiSettings().setZoomControlsEnabled(true);

			// Enable / Disable my location button
			googleMap.getUiSettings().setMyLocationButtonEnabled(true);

			// Enable / Disable Compass icon
			googleMap.getUiSettings().setCompassEnabled(true);

			// Enable / Disable Rotate gesture
			googleMap.getUiSettings().setRotateGesturesEnabled(true);

			// Enable / Disable zooming functionality
			googleMap.getUiSettings().setZoomGesturesEnabled(true);
			
			
			double latitude = 11.597916;
			double longitude = 43.148773;
			// random latitude and logitude
			double[] randomLocation = createRandLocation(latitude,
					longitude);

			// Adding a marker
			MarkerOptions marker = new MarkerOptions().position(
					new LatLng(randomLocation[0], randomLocation[1]))
					.title("w3w");

			
			
			googleMap.addMarker(marker).showInfoWindow();

			
			Log.e("Random", "> " + randomLocation[0] + ", "
					+ randomLocation[1]);
			
			CameraPosition cameraPosition = new CameraPosition.Builder()
			.target(new LatLng(randomLocation[0],
					randomLocation[1])).zoom(15).build();

	googleMap.animateCamera(CameraUpdateFactory
			.newCameraPosition(cameraPosition));
			
			

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//bouton normal
		public void normal(View v){
			googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
		}
		//bouton hybrid
		public void hybrid(View v){
			googleMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
		}
		//bouton satellite
		public void satellite(View v){
			googleMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
		}
		//bouton terrain
		public void terrain(View v){
			googleMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
		}

		@Override
		protected void onResume() {
			super.onResume();
			initilizeMap();
		}

		/**
		 * function to load map If map is not created it will create it for you
		 * */
		private void initilizeMap() {
			if (googleMap == null) {
				googleMap = ((MapFragment) getFragmentManager().findFragmentById(
						R.id.map)).getMap();

				// check if map is created successfully or not
				if (googleMap == null) {
					Toast.makeText(getApplicationContext(),
							"Sorry! unable to create maps", Toast.LENGTH_SHORT)
							.show();
				}
			}
			
		}

		/*
		 * creating random postion around a location for testing purpose only
		 */
		private double[] createRandLocation(double latitude, double longitude) {

			return new double[] { latitude + ((Math.random() - 0.5) / 500),
					longitude + ((Math.random() - 0.5) / 500),
					150 + ((Math.random() - 0.5) * 10) };
		}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.geo_localisation, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
