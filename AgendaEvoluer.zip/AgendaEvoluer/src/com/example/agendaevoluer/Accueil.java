package com.example.agendaevoluer;



import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;



import Dao.EvenementDao;
import Dao.UtilisateurDao;
import Entity.Evenement;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

public class Accueil extends Activity {
	
	EvenementDao eventDao;
	List<Evenement> listEvents=new ArrayList<Evenement>();
	List<Long> listDateBebut = new ArrayList<Long>();
	Timestamp timestamp;
	private static final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy h:mm a");
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_accueil);
		setTitle("Accueil");
        //setAlarm(System.currentTimeMillis() + 5 * 1000);
		
	    //afficherList();
		
		//pour tester la base de donnee
		//testUtilisateur();
		//testInfoUser();
	}
	
	/*public void afficherList() throws ParseException {
		
		eventDao=new EvenementDao(this);
		eventDao.open();
		listEvents=eventDao.listEvenement();
		eventDao.close();
		//on recupere la date du system local
		timestamp = new Timestamp(System.currentTimeMillis());
		//on formate le timestamp du system recuperee sous "dd/MM/yyyy h:mm a"
		String s = new SimpleDateFormat("dd/MM/yyyy h:mm a").format(timestamp);
		//on parse le timestamp en date selon notre format
		Date parsedDate1 = sdf.parse(s);
		//on caste notre date en time de type Long
		long currentTime=parsedDate1.getTime();
		//String localtime;
		//localtime=sdf.format(timestamp);
		for (Evenement ev : listEvents) {
			//conversion des donnees en Date
			Date parsedDate = sdf.parse(ev.getDate_debut());
			 long milli = parsedDate.getTime();
			 
			 listDateBebut.add(milli);			
		}
		//boucle pour verifier le registre des notification 
		//afin de lancer l'alarme
		for(int i=0;i<listDateBebut.size();i++) {
			long thistime=listDateBebut.get(i);
			setAlarm(thistime);
			Toast.makeText(this,"OK!!!",Toast.LENGTH_SHORT).show();
			if(thistime==currentTime) {
				setAlasrm(thistime);
			}
			else {
				Toast.makeText(this,"Pas encore!!!",Toast.LENGTH_SHORT).show();
			}
		}
		
		for(int i=0;i<mylistevent.size();i++) {
			if(mylistevent.contains(localtime)) {
				Toast.makeText(this,"Times up please!!!",Toast.LENGTH_LONG).show();
			}
		}
		
	}
	
	//methode pour lancer l'alarme
	private void setAlarm(long temps) {
        //obtenir le gestionnaire d'alarme
        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        
        //cr�er une nouvelle intention sp�cifiant le r�cepteur de diffusion
        Intent i = new Intent(this, AlarmReceiver.class);
        
        //cr�er une intention en attente en utilisant l'intention
        PendingIntent pi = PendingIntent.getBroadcast(this, 0, i, 0);
        
        //R�glage de l'alarme r�p�t�e qui sera d�clench�e a un temps choisis 
        //via AlarmManager.RTC_WAKEUP
        //am.setRepeating(AlarmManager.RTC, temps, AlarmManager.RTC_WAKEUP, pi);
        am.set(AlarmManager.RTC, temps,pi );
        Toast.makeText(this, "Alarm is set", Toast.LENGTH_SHORT).show();
    }*/

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.accueil, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	//pour tester
	/*
	public void testInfoUser() {
		EvenementDao m=new EvenementDao(this);
		m.open();
		//m.AjouterUtilisateur(new Utilisateur(1,"HASSAN FARAH","Mouktar","mowlide10@gmail.com"));
				
		Cursor c=m.getListEvenement();		
		String _titre,_lieu,_description,_dateDebut,_type,_dateFin,_alerte;
		int _id;
		
		
		if(c.moveToFirst()){
			do{
				_id=c.getInt(c.getColumnIndex(EvenementDao.KEY_ID_EVENEMENT));
				_titre=c.getString(c.getColumnIndex(EvenementDao.KEY_TITRE_EVENEMENT));
				_lieu=c.getString(c.getColumnIndex(EvenementDao.KEY_LIEU_EVENEMENT));
				_description=c.getString(c.getColumnIndex(EvenementDao.KEY_DESCRIPTION_EVENEMENT));
				_dateDebut=c.getString(c.getColumnIndex(EvenementDao.KEY_DATE_DEBUT_EVENEMENT));
				_dateFin=c.getString(c.getColumnIndex(EvenementDao.KEY_DATE_FIN_EVENEMENT));
				_type=c.getString(c.getColumnIndex(EvenementDao.KEY_TYPE_EVENEMENT));
				_alerte=c.getString(c.getColumnIndex(EvenementDao.KEY_ALERTE_EVENEMENT));
							
				
				
			}
			while(c.moveToNext());
		}
		
		c.close();//fermeture du curseur
		
		//fermeture du gestionnaire
		m.close();
		
	}*/
	
public void testUtilisateur(){
		
		UtilisateurDao m=new UtilisateurDao(this);
		m.open();
		//m.AjouterUtilisateur(new Utilisateur(1,"HASSAN FARAH","Mouktar","mowlide10@gmail.com"));
				
		Cursor c=m.getListUtilisateur();
		if(c.moveToFirst()){
			do{
				int _id=c.getInt(c.getColumnIndex(UtilisateurDao.KEY_ID_UTILISATEUR));
				String _nom=c.getString(c.getColumnIndex(UtilisateurDao.KEY_NOM_UTILISATEUR));
				String _prenom=c.getString(c.getColumnIndex(UtilisateurDao.KEY_PRENOM_UTILISATEUR));
				String _email=c.getString(c.getColumnIndex(UtilisateurDao.KEY_EMAIL_UTILISATEUR));			
				
				Toast.makeText(
						this,
						"Bienvenu: " + _nom+ ","+ _prenom+ ")",Toast.LENGTH_LONG).show();
			}
			while(c.moveToNext());
		}
		c.close();//fermeture du curseur
		
		//fermeture du gestionnaire
		m.close();
	}


//image bouton Ajout
		public void AjouterEvent(View v){
			Intent i=new Intent(Accueil.this,EventAddForm.class);
			startActivity(i);
		}
		
		//image bouton affichage notification
		public void AfficherNotification(View v) {
			Intent i=new Intent(Accueil.this,AfficherNotification.class);
			startActivity(i);
		}
		
		//image bouton pour affichage evenements
		public void AfficherEvenement(View v) {
			Intent i=new Intent(Accueil.this,AfficherEvenement.class);
			startActivity(i);
		}
		
		//image bouton pour afficher le map
		public void afficherMap(View v) {
			Intent i=new Intent(Accueil.this,GeoLocalisation.class);
			startActivity(i);
			/*Intent i=new Intent(Accueil.this,Geocode.class);
			startActivity(i);*/
		}
		
		
	
}
