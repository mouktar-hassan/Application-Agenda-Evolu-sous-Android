package com.example.agendaevoluer;

import java.util.ArrayList;
import java.util.List;


import Dao.EvenementDao;
import Entity.Evenement;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

public class DetailleEvenement extends Activity {
	
	WebView webEvent;
	EvenementDao eventDao;
	String id_event;
	Intent intentesource = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_detaille_evenement);
		
		webEvent=(WebView)findViewById(R.id.webViewEvents);
		WebSettings settings = webEvent.getSettings();
		settings.setDefaultTextEncodingName("utf-8");
		
		intentesource = getIntent();
		id_event=intentesource.getStringExtra("v_id");
		
		AfficherDetaille();
	}

	private void AfficherDetaille() {
		eventDao=new EvenementDao(this);
		eventDao.open();
		Evenement event=eventDao.getEvenement(Integer.parseInt(id_event));
		eventDao.close();
		
		String mapage = "<form method=post ><TABLE BORDER=0 width=100%><TR><TH COLSPAN=4 BGCOLOR=cyan><FONT color=green>Les informations de l'evenement</font></TH></TR>"
				+ "<TR><TD ALIGN=right><FONT color=red>Titre :</font></TD> <TD  ALIGN=left>" + event.getTitre()
				+ "</TD> </TR>"
				+ "<TR><TD ALIGN=right><FONT color=red>T�l�phone :</font></TD> <TD COLSPAN=4  ALIGN=left>"
				+ event.getLieu() + "</TD> </TR>"
				+ "<TR><TD  ALIGN=right><FONT color=red>Date debut :</font></TD> <TD  COLSPAN=4 ALIGN=left>"
				+ event.getDate_debut() + "</TD> </TR>"
				+ "<TR><TD ALIGN=right><FONT color=red>Date fin :</font></TD> <TD COLSPAN=4 ALIGN=left>"
				+ event.getDate_fin() + "</TD> </TR>"
			    + "<TR><TD ALIGN=right><FONT color=red>Type :</font></TD> <TD COLSPAN=4 ALIGN=left>"
			    + event.getType() + "</TD> </TR>"
			    + "<TR><TD ALIGN=right><FONT color=red>Description :</font></TD> <TD COLSPAN=4 ALIGN=left>"
				+ event.getDescription() + "</TD> </TR>"
		        + "<TR><TD ALIGN=right><FONT color=red>Alerte :</font></TD> <TD COLSPAN=4 ALIGN=left>"
				+ event.getAlerte() + "</TD> </TR>";
				

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.FROYO) {
			String base64 = Base64.encodeToString(mapage.getBytes(), Base64.DEFAULT);
			webEvent.loadData(base64, "text/html; charset=utf-8", "base64");
		} else {
			String header = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>";
			webEvent.loadData(header + mapage, "text/html; charset=UTF-8", null);
		}
	}
	
	//methode pour modifier evenement
	public void Modifier(View v) {
		List<Evenement> listEvents=new ArrayList<Evenement>();
		
		EvenementDao eventDao=new EvenementDao(this);
		eventDao.open();
		Evenement event=eventDao.getEvenement(Integer.parseInt(id_event));
		eventDao.close();
		int _id;
		String _titre,_lieu,_description,_type,_dateDebut,_dateFin,_alerte;
		//on recupere les infos 
		_id=event.getIdEve();
		_titre=event.getTitre();
		_lieu=event.getLieu();
		_dateDebut=event.getDate_debut();
		_dateFin=event.getDate_fin();
		_description=event.getDescription();
		_type=event.getType();
		_alerte=event.getAlerte();
		
				
		Intent myintent = new Intent(DetailleEvenement.this, ModifierEvent.class);
		myintent.putExtra("v_id", ""+_id);
		myintent.putExtra("v_titre",_titre);
		myintent.putExtra("v_lieu",_lieu);
		myintent.putExtra("v_dateDebut",_dateDebut);
		myintent.putExtra("v_dateFin",_dateFin);
		myintent.putExtra("v_description",_description);
		myintent.putExtra("v_alerte",""+_alerte);
		startActivity(myintent);
		
	}
	
	//methode pour supprimer evenement
	public void Supprimer(View v) {
		eventDao=new EvenementDao(this);
		eventDao.open();
		Evenement event=eventDao.getEvenement(Integer.parseInt(id_event));
		int id=event.getIdEve();		
	    eventDao.SupprimerEvenement(eventDao.getEvenement(id));		
	    eventDao.close();
		Toast.makeText(this,"Suppression avec success!",Toast.LENGTH_LONG).show();		
		Intent intent=new Intent(v.getContext(),Accueil.class);
		startActivityForResult(intent, 0);

		
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.detaille_evenement, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
