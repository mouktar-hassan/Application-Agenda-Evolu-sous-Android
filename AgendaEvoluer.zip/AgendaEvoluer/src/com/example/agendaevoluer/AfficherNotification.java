package com.example.agendaevoluer;

import java.util.ArrayList;
import java.util.List;

import Dao.EvenementDao;
import Dao.NotificationDao;
import Entity.Evenement;
import Entity.Notifications;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class AfficherNotification extends Activity {

	ListView listNoti;
	Cursor notiCurseur;
	NotificationDao notifiDao=new NotificationDao(this);
	List<String> mylist = new ArrayList<String>();
	List<Notifications> listnotification=new ArrayList<Notifications>();
	List<String> listTitre=new ArrayList<String>();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_afficher_notification);
		
		afficherList();
		
		listNoti=(ListView)findViewById(R.id.listViewNotification);
		
		
		
		ArrayAdapter<String> arrayAdapter  = new ArrayAdapter<String>(getApplicationContext(), 
				android.R.layout.simple_spinner_item,mylist);
		arrayAdapter.setDropDownViewResource(R.layout.activity_afficher_notification);
		listNoti.setAdapter(arrayAdapter);
		
		listNoti.setOnItemClickListener(new OnItemClickListener() {
			
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// TODO Auto-generated method stub
				
				String chaine;
				for(int i=0;i<listnotification.size();i++) {
					chaine=listnotification.get(i).getIdAgenda()+"\t\t "+listnotification.get(i).getTitre()+"\t\t "+
							listnotification.get(i).getDescription();
					if(chaine.equals(parent.getItemAtPosition(position))) {
						String _titre,_dateDebut,_description;
						long _idNotit;
						_idNotit=listnotification.get(i).getIdAgenda();
						_titre=listnotification.get(i).getTitre();
						_dateDebut=listnotification.get(i).getdate_debut_event();
						_description=listnotification.get(i).getDescription();						
						Intent myintent = new Intent(AfficherNotification.this, DetailleNotification.class);
						myintent.putExtra("v_id", ""+_idNotit);
						myintent.putExtra("v_titre",_titre);						
						myintent.putExtra("v_dateDebut",_dateDebut);						
						myintent.putExtra("v_description",_description);
						
						startActivity(myintent);
						break;
					}
			
					
				}
				
			}
		});
		
		
	}
	
	
	
	public void afficherList() {
		notifiDao=new NotificationDao(this);
		notifiDao.open();
		listnotification=notifiDao.listNotification();
		notifiDao.close();
		for (Notifications noti : listnotification) {
			mylist.add(noti.getIdAgenda()+ "\t\t " + noti.getTitre() + "\t\t " + noti.getDescription());
			listTitre.add(noti.getTitre());
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.afficher_notification, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
